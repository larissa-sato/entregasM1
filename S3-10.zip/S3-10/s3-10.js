/*
1. Crie uma função chamada positions, esta função deverá receber como argumento 3 parâmetros; firstPlace, secondPlace, lastPlace
2. Você deverá criar uma array composto pelos três parâmetros recebidos pela função. A posição em que o parâmetro é inserido no array, é considerado a posição do atleta na corrida.
3. O competidor Daniel realizou o desafio extra, e ganhou um bônus. Ele sempre vai subir uma posição. Sendo assim, o Daniel trocará de lugar com quem estiver na posição a frente dele, caso haja.
4. Após realizar esta rotina a função deverá imprimir no console o resultado. Deverá seguir o seguinte modelo: 1ª - Colocado "nomeDoCompetidor". Queremos saber a posição de todos os 3 primeiros colocados
*/

/*
RUBRICA: 
1. Criou a função corretamente
2. Gerou o array de forma correta utilizando as valores recebidos como parametro
3. Verificou os dados recebidos com estrutura condicional
4. Imprimiu no console o resultado final
*/

const nomeDoCompetidor = ['Daniel', 'Pedro', 'Jose']

function positions (firstPlace, secondPlace, lastPlace){
    //console.log(firstPlace)

    if(firstPlace==='Daniel'){
        return (nomeDoCompetidor)
    }
    if(secondPlace==='Daniel'){
            let primeiro = 'Daniel'
            let segundo = nomeDoCompetidor[1]
            let terceiro = nomeDoCompetidor[2]
        return `1º Colocado: ${primeiro}; 2º Colocado: ${segundo}; 3º Colocado: ${terceiro}.`
    }
    if(lastPlace==='Daniel'){
            let segundo = 'Daniel';
            let primeiro = nomeDoCompetidor[0]
            let terceiro = nomeDoCompetidor[2]
        return `1º Colocado: ${primeiro}; 2º Colocado: ${segundo}; 3º Colocado: ${terceiro}.`
    }
}

/*
else if(secondPlace==='Daniel'){
       let primeiro = `${firstPlace} : Daniel`
       let segundo = `${secondPlace} : ${nomeDoCompetidor[1]}`
       let terceiro = `${lastPlace} : ${nomeDoCompetidor[2]}`
*/